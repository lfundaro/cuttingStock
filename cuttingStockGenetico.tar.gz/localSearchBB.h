#ifndef LOCALSEARCHBB
#define LOCALSEARCHBB
#include <vector>
#define LSBB_MAXIT 10000 // Criterio de parada

using namespace std;

void localSearchBB(vector<vector<int>*> &, 
                   vector<int> &, vector<int> &,
                   vector<int> &, vector<int> &,
                   vector<int> &, vector<int> &,
		   vector<int> &);

#endif

