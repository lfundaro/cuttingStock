#ifndef utilities
#define utilities
#include <utility>
#include <vector>
#include <limits>
#define MAX_INT numeric_limits<int>::max()
using namespace std;

bool comparePair(pair<int,int>, pair<int,int>);

bool comparePairDouble(pair<int,double> a, pair<int,double> b);

bool group_quality(int *, vector<int> &,
                   vector<int> &);


vector<vector<int>*> genInitSol(vector<int> &, 
                                vector<int> &,
                                vector<int> &,
                                vector<int> &,
                                vector<int> &,
                                vector<int> &);


int* bestCutting(vector<int>& pieceSet, 
                 vector<int>& rlength,
                 vector<int>& lpiece);

int notEmptyColumn(vector<int> column);


#endif
