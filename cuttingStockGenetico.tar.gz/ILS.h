#include "localSearchBB.h"
#include "utilities.h"
#include ILS_MAXIT 1000  // Criterio de parada
#include MAX_PERTURB 3
#include PROB_MARGIN 0.5 // Margen de probabilidad 
#include EXP_DESC 0.85   // Descenso exponencial
