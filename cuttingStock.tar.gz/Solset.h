class solSet {
 public:
  
};
