#include "genetic.h"
using namespace std;

Solution* randomSol(Solution initial) {
  int n = NUM_PERTURBATIONS;
  int candidate;
  for(int i = 0; i < n; I++) {
    srand(time(NULL));
    candidate = rand() % initial.size;
    
    
  }
}
