#ifndef PERTURB
#define PERTURB
#include <vector>
#include <iostream>
#include <limits>
#include <math.h>

#include "shiftSpace.h"
#include "utilities.h"

using namespace std;

//vector<vector<int>*>
void Perturb(vector<vector<int>*>&,vector<int>&,
	     vector<int>&,vector<int>&,
	     vector<int>&,vector<int>&,vector<int>&,
	     int);
#endif
