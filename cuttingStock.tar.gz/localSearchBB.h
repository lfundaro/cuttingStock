#ifndef LOCALSEARCHBB
#define LOCALSEARCHBB

#include <vector>

#include "shiftSpace.h"
#include "tunning.h"

using namespace std;

void localSearchBB(vector<vector<int>*> &, 
                   vector<int> &, vector<int> &,
                   vector<int> &, vector<int> &,
                   vector<int> &, vector<int> &,
		   vector<int> &);

#endif

