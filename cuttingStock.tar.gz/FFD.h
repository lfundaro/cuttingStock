
#include <vector>
#include <utility>
#include <algorithm>
#include <iostream>
using namespace std;

pair<int,int> FFD(int,vector<int>,vector<int>);

void free_vector(vector<vector<int>*> &);

int leftOver(vector<vector<int>*>, int, vector<int>);

int emptyPieceSet(vector<int>);


