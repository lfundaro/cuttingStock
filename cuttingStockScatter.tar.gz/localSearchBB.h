#ifndef LOCALSEARCHBB
#define LOCALSEARCHBB
#include <vector>
#include "tunning.h"
#include "Solution.h"
#include <math.h>
using namespace std;

void localSearchBB(Solution &, 
                   vector<int> & ,vector<int> & , 
                   vector<int> & ,vector<int> & );
#endif

